<template>
  <Signin />
</template>
<script>
import Signin from "../components/Signin/Signin.vue";

export default {
  name: "Login",
  components: { Signin },
};
</script>
<style></style>
