<template>
  <Signup />
</template>
<script>
import Signup from "../components/Signup/Signup.vue";

export default {
  name: "Registration",
  components: { Signup },
};
</script>
<style></style>
